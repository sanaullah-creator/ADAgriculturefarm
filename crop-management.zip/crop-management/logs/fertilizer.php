<?php
// logs/fertilizer.php
require_once '../db.php';
require_once '../auth.php';
requireLogin();

$crop_id = isset($_GET['crop_id']) ? (int)$_GET['crop_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (verify_csrf($_POST['csrf_token'] ?? '')) {
        $stmt = $pdo->prepare("
            INSERT INTO fertilizer_logs 
            (crop_id, fertilizer_name, application_date, quantity, unit, notes) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $crop_id,
            trim($_POST['fertilizer_name']),
            $_POST['application_date'],
            (float)$_POST['quantity'],
            $_POST['unit'],
            trim($_POST['notes'] ?? '')
        ]);

        header("Location: ../crops/view.php?id=$crop_id&success=Fertilizer recorded");
        exit();
    }
}
?>

<?php include '../includes/header.php'; ?>
<?php include '../includes/navbar.php'; ?>

<div class="max-w-lg mx-auto bg-white rounded-3xl shadow-xl p-8 mt-12">
    <h1 class="text-3xl font-bold mb-8 text-center">🌿 Fertilizer Application</h1>
    
    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
        
        <div class="space-y-6">
            <div>
                <label class="block text-sm font-medium mb-2">Fertilizer Name</label>
                <input type="text" name="fertilizer_name" required placeholder="e.g. Urea, DAP"
                       class="w-full px-4 py-3 border rounded-2xl">
            </div>
            
            <div class="grid grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium mb-2">Date</label>
                    <input type="date" name="application_date" value="<?= date('Y-m-d') ?>" required 
                           class="w-full px-4 py-3 border rounded-2xl">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Quantity</label>
                    <input type="number" step="0.01" name="quantity" required 
                           class="w-full px-4 py-3 border rounded-2xl">
                </div>
            </div>
            
            <div>
                <label class="block text-sm font-medium mb-2">Notes</label>
                <textarea name="notes" rows="3" class="w-full px-4 py-3 border rounded-3xl"></textarea>
            </div>
        </div>

        <button type="submit" 
                class="mt-10 w-full bg-amber-600 hover:bg-amber-700 text-white py-4 rounded-2xl font-semibold">
            Save Fertilizer Log
        </button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>