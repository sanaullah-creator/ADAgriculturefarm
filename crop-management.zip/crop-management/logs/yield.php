<?php
// logs/yield.php
require_once '../db.php';
require_once '../auth.php';
requireLogin();

$crop_id = isset($_GET['crop_id']) ? (int)$_GET['crop_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (verify_csrf($_POST['csrf_token'] ?? '')) {
        $stmt = $pdo->prepare("
            INSERT INTO yields (crop_id, harvest_date, amount, unit, notes) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $crop_id,
            $_POST['harvest_date'],
            (float)$_POST['amount'],
            $_POST['unit'],
            trim($_POST['notes'] ?? '')
        ]);

        // Update crop status to Harvested
        $pdo->prepare("UPDATE crops SET status = 'Harvested' WHERE id = ?")
             ->execute([$crop_id]);

        header("Location: ../crops/view.php?id=$crop_id&success=Yield recorded");
        exit();
    }
}
?>

<?php include '../includes/header.php'; ?>
<?php include '../includes/navbar.php'; ?>

<div class="max-w-lg mx-auto bg-white rounded-3xl shadow-xl p-8 mt-12">
    <h1 class="text-3xl font-bold mb-8 text-center">📊 Record Harvest Yield</h1>
    
    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
        
        <div class="space-y-6">
            <div>
                <label class="block text-sm font-medium mb-2">Harvest Date</label>
                <input type="date" name="harvest_date" value="<?= date('Y-m-d') ?>" required 
                       class="w-full px-4 py-3 border rounded-2xl">
            </div>
            
            <div class="grid grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium mb-2">Yield Amount</label>
                    <input type="number" step="0.01" name="amount" required 
                           class="w-full px-4 py-3 border rounded-2xl">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Unit</label>
                    <select name="unit" class="w-full px-4 py-3 border rounded-2xl">
                        <option value="kg">Kilograms (kg)</option>
                        <option value="tons">Tons</option>
                        <option value="quintal">Quintal</option>
                    </select>
                </div>
            </div>
            
            <div>
                <label class="block text-sm font-medium mb-2">Notes</label>
                <textarea name="notes" rows="4" class="w-full px-4 py-3 border rounded-3xl"></textarea>
            </div>
        </div>

        <button type="submit" 
                class="mt-10 w-full bg-emerald-600 hover:bg-emerald-700 text-white py-4 rounded-2xl font-semibold">
            Save Yield & Mark Harvested
        </button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>