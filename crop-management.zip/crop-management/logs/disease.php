<?php
// logs/disease.php
require_once '../db.php';
require_once '../auth.php';
requireLogin();

$crop_id = isset($_GET['crop_id']) ? (int)$_GET['crop_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (verify_csrf($_POST['csrf_token'] ?? '')) {
        $stmt = $pdo->prepare("
            INSERT INTO crop_diseases (crop_id, disease_name, detection_date, treatment, notes) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $crop_id,
            trim($_POST['disease_name']),
            $_POST['detection_date'],
            trim($_POST['treatment'] ?? ''),
            trim($_POST['notes'] ?? '')
        ]);

        header("Location: ../crops/view.php?id=$crop_id&success=Disease recorded");
        exit();
    }
}
?>

<?php include '../includes/header.php'; ?>
<?php include '../includes/navbar.php'; ?>

<div class="max-w-lg mx-auto bg-white rounded-3xl shadow-xl p-8 mt-12">
    <h1 class="text-3xl font-bold mb-8 text-center">🦠 Record Disease / Pest</h1>
    
    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
        
        <div class="space-y-6">
            <div>
                <label class="block text-sm font-medium mb-2">Disease / Pest Name</label>
                <input type="text" name="disease_name" required 
                       class="w-full px-4 py-3 border rounded-2xl">
            </div>
            
            <div>
                <label class="block text-sm font-medium mb-2">Detection Date</label>
                <input type="date" name="detection_date" value="<?= date('Y-m-d') ?>" required 
                       class="w-full px-4 py-3 border rounded-2xl">
            </div>
            
            <div>
                <label class="block text-sm font-medium mb-2">Treatment Applied</label>
                <textarea name="treatment" rows="3" class="w-full px-4 py-3 border rounded-3xl"></textarea>
            </div>
            
            <div>
                <label class="block text-sm font-medium mb-2">Notes</label>
                <textarea name="notes" rows="3" class="w-full px-4 py-3 border rounded-3xl"></textarea>
            </div>
        </div>

        <button type="submit" 
                class="mt-10 w-full bg-red-600 hover:bg-red-700 text-white py-4 rounded-2xl font-semibold">
            Save Disease Record
        </button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>