<?php
// logs/water.php
require_once '../db.php';
require_once '../auth.php';
requireLogin();

$crop_id = isset($_GET['crop_id']) ? (int)$_GET['crop_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (verify_csrf($_POST['csrf_token'] ?? '')) {
        $stmt = $pdo->prepare("
            INSERT INTO watering_logs (crop_id, watering_date, amount_ml, notes) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $crop_id,
            $_POST['watering_date'],
            (int)$_POST['amount_ml'],
            trim($_POST['notes'] ?? '')
        ]);

        header("Location: ../crops/view.php?id=$crop_id&success=Watering recorded");
        exit();
    }
}
?>

<?php include '../includes/header.php'; ?>
<?php include '../includes/navbar.php'; ?>

<div class="max-w-lg mx-auto bg-white rounded-3xl shadow-xl p-8 mt-12">
    <h1 class="text-3xl font-bold mb-8 text-center">💧 Record Watering</h1>
    
    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
        
        <div class="space-y-6">
            <div>
                <label class="block text-sm font-medium mb-2">Watering Date</label>
                <input type="date" name="watering_date" value="<?= date('Y-m-d') ?>" required 
                       class="w-full px-4 py-3 border rounded-2xl focus:outline-none focus:border-blue-500">
            </div>
            
            <div>
                <label class="block text-sm font-medium mb-2">Amount (ml)</label>
                <input type="number" name="amount_ml" placeholder="500" required 
                       class="w-full px-4 py-3 border rounded-2xl focus:outline-none focus:border-blue-500">
            </div>
            
            <div>
                <label class="block text-sm font-medium mb-2">Notes (Optional)</label>
                <textarea name="notes" rows="4" 
                          class="w-full px-4 py-3 border rounded-3xl focus:outline-none focus:border-blue-500"></textarea>
            </div>
        </div>

        <button type="submit" 
                class="mt-10 w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-2xl font-semibold text-lg">
            Save Watering Record
        </button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>