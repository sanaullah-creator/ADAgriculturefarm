<!-- includes/navbar.php -->
<nav class="bg-green-700 text-white shadow-lg">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 py-4">
        <div class="flex justify-between items-center">
            <!-- Logo -->
            <div class="flex items-center gap-3">
                <i class="fas fa-seedling text-3xl"></i>
                <h1 class="text-xl sm:text-2xl font-bold">AD Agriculture Farm</h1>
            </div>
            
            <!-- Desktop + Tablet Menu -->
            <div class="hidden md:flex items-center gap-6 lg:gap-8 text-sm font-medium">
                <a href="/index.php" class="hover:text-green-200 flex items-center gap-1">
                    <i class="fas fa-home"></i> <span class="hidden lg:inline">Dashboard</span>
                </a>
                <a href="/crops/index.php" class="hover:text-green-200 flex items-center gap-1">
                    <i class="fas fa-leaf"></i> <span class="hidden lg:inline">My Crops</span>
                </a>
                <a href="/exports/export-csv.php" class="hover:text-green-200 flex items-center gap-1">
                    <i class="fas fa-download"></i> <span class="hidden lg:inline">Export</span>
                </a>
                
                <div class="flex items-center gap-4 pl-6 border-l border-green-500">
                    <span class="text-sm hidden sm:block">👤 <?= htmlspecialchars($_SESSION['username'] ?? '') ?></span>
                    <a href="/logout.php" 
                       class="bg-red-600 hover:bg-red-700 px-5 py-2 rounded-xl text-sm font-medium">
                        Logout
                    </a>
                </div>
            </div>

            <!-- Mobile Menu Button -->
            <button class="md:hidden text-3xl focus:outline-none" id="mobile-btn">
                <i class="fas fa-bars"></i>
            </button>
        </div>

        <!-- Mobile Menu -->
        <div id="mobile-menu" class="hidden md:hidden mt-4 pt-4 border-t border-green-600">
            <div class="flex flex-col gap-4 text-sm font-medium">
                <a href="/index.php" class="hover:text-green-200 py-2 flex items-center gap-2">
                    <i class="fas fa-home"></i> Dashboard
                </a>
                <a href="/crops/index.php" class="hover:text-green-200 py-2 flex items-center gap-2">
                    <i class="fas fa-leaf"></i> My Crops
                </a>
                <a href="/exports/export-csv.php" class="hover:text-green-200 py-2 flex items-center gap-2">
                    <i class="fas fa-download"></i> Export
                </a>
                
                <div class="pt-4 border-t border-green-600 flex justify-between items-center">
                    <span>👤 <?= htmlspecialchars($_SESSION['username'] ?? '') ?></span>
                    <a href="/logout.php" 
                       class="bg-red-600 hover:bg-red-700 px-6 py-2 rounded-xl text-sm font-medium">
                        Logout
                    </a>
                </div>
            </div>
        </div>
    </div>
</nav>

<script>
    // Simple Mobile Toggle
    document.getElementById('mobile-btn').addEventListener('click', function() {
        const menu = document.getElementById('mobile-menu');
        menu.classList.toggle('hidden');
    });
</script>