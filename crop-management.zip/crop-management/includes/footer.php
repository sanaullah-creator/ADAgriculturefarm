<!-- includes/footer.php -->
<footer class="bg-white border-t py-6 mt-12">
    <div class="max-w-6xl mx-auto px-4 text-center text-gray-500 text-sm">
        
        <!-- Brand -->
        <h2 class="text-lg font-semibold text-green-600 mb-2">
            AD Agriculture Farm
        </h2>

        <!-- Links -->
        <div class="flex justify-center flex-wrap gap-4 mb-3">
            <a href="/index.php" class="hover:text-green-200 flex items-center gap-1">
                <i class="fas fa-home"></i> Dashboard
            </a>
            <a href="/crops/index.php" class="hover:text-green-200 flex items-center gap-1">
                <i class="fas fa-leaf"></i> My Crops
            </a>
            <a href="/exports/export-csv.php" class="hover:text-green-200 flex items-center gap-1">
                <i class="fas fa-download"></i> Export
            </a>
        </div>

        <!-- Divider -->
        <div class="border-t my-3"></div>

        <!-- Copyright -->
        <p>
            &copy; <?= date("Y") ?> AD Agriculture Farm. All Rights Reserved.
        </p>

        <!-- Extra Note -->
        <p class="mt-1 text-xs text-gray-400">
            Designed for smart crop management 🌱
        </p>

    </div>
</footer>
</body>
</html>