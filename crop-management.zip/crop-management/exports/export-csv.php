<?php
// exports/export-csv.php
require_once '../db.php';
require_once '../auth.php';
requireLogin();

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="crops_export_' . date('Y-m-d') . '.csv"');

$output = fopen('php://output', 'w');
fputcsv($output, ['Crop Name', 'Field', 'Planting Date', 'Expected Harvest', 'Current Stage', 'Status']);

$stmt = $pdo->prepare("
    SELECT ct.name as crop_name, c.field_name, c.planting_date, c.expected_harvest_date, 
           c.current_stage, c.status 
    FROM crops c 
    JOIN crop_types ct ON c.crop_type_id = ct.id 
    WHERE c.user_id = ?
");
$stmt->execute([$_SESSION['user_id']]);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($output, $row);
}

fclose($output);
exit();
?>