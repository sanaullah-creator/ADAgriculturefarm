<?php
// crops/index.php
require_once '../db.php';
require_once '../auth.php';
requireLogin();
?>

<?php include '../includes/header.php'; ?>
<?php include '../includes/navbar.php'; ?>

<div class="max-w-7xl mx-auto px-6 py-8">
    <div class="flex justify-between items-center mb-8">
        <div>
            <h1 class="text-3xl font-bold text-gray-800">All Crops</h1>
            <p class="text-gray-600">Manage all your crops in one place</p>
        </div>
        <a href="create.php" 
           class="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-2xl flex items-center gap-2 font-semibold">
            <i class="fas fa-plus"></i> Add New Crop
        </a>
    </div>

    <!-- Search -->
    <div class="mb-6">
        <input type="text" id="searchInput" 
               class="w-full md:w-96 px-5 py-3 border border-gray-300 rounded-2xl focus:outline-none focus:border-green-500"
               placeholder="Search by crop name or field...">
    </div>

    <div class="bg-white rounded-3xl shadow overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50 border-b">
                <tr>
                    <th class="px-6 py-5 text-left font-semibold">Crop</th>
                    <th class="px-6 py-5 text-left font-semibold">Field</th>
                    <th class="px-6 py-5 text-left font-semibold">Area</th>
                    <th class="px-6 py-5 text-left font-semibold">Stage</th>
                    <th class="px-6 py-5 text-left font-semibold">Planted</th>
                    <th class="px-6 py-5 text-left font-semibold">Harvest</th>
                    <th class="px-6 py-5 text-center font-semibold">Status</th>
                    <th class="px-6 py-5 text-center font-semibold">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y" id="cropTable">
                <?php
                $stmt = $pdo->prepare("
                    SELECT c.*, ct.name as crop_name,
                           DATEDIFF(c.expected_harvest_date, CURDATE()) as days_to_harvest
                    FROM crops c
                    JOIN crop_types ct ON c.crop_type_id = ct.id
                    WHERE c.user_id = ?
                    ORDER BY c.expected_harvest_date ASC, c.planting_date DESC
                ");
                $stmt->execute([$_SESSION['user_id']]);
                
                while ($row = $stmt->fetch()):
                ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-5 font-medium"><?= htmlspecialchars($row['crop_name']) ?></td>
                    <td class="px-6 py-5"><?= htmlspecialchars($row['field_name']) ?></td>
                    <td class="px-6 py-5"><?= $row['area_acres'] ?> acres</td>
                    <td class="px-6 py-5">
                        <span class="inline-block px-4 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-700">
                            <?= $row['current_stage'] ?>
                        </span>
                    </td>
                    <td class="px-6 py-5"><?= $row['planting_date'] ?></td>
                    <td class="px-6 py-5 font-medium <?= $row['days_to_harvest'] <= 14 ? 'text-amber-600' : '' ?>">
                        <?= $row['expected_harvest_date'] ?>
                        <?php if($row['days_to_harvest'] > 0): ?>
                            <span class="text-xs text-gray-500">(<?= $row['days_to_harvest'] ?> days)</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-5 text-center">
                        <span class="inline-block px-5 py-1 text-xs font-semibold rounded-full
                            <?= $row['status'] == 'Active' ? 'bg-green-100 text-green-700' : 
                               ($row['status'] == 'Harvested' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700') ?>">
                            <?= $row['status'] ?>
                        </span>
                    </td>
                    <td class="px-6 py-5 text-center space-x-4">
                        <a href="view.php?id=<?= $row['id'] ?>" 
                           class="text-blue-600 hover:text-blue-700 font-medium">View</a>
                        <a href="edit.php?id=<?= $row['id'] ?>" 
                           class="text-amber-600 hover:text-amber-700 font-medium">Edit</a>
                        <a href="delete.php?id=<?= $row['id'] ?>&csrf=<?= csrf_token() ?>" 
                           onclick="return confirm('Delete this crop and all its logs?')" 
                           class="text-red-600 hover:text-red-700 font-medium">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <?php if($stmt->rowCount() == 0): ?>
    <div class="text-center py-20 bg-white rounded-3xl shadow">
        <p class="text-6xl mb-4">🌱</p>
        <p class="text-xl text-gray-500">No crops found. Add your first crop!</p>
    </div>
    <?php endif; ?>
</div>

<script>
// Simple Search Functionality
document.getElementById('searchInput').addEventListener('keyup', function() {
    const filter = this.value.toLowerCase();
    const rows = document.querySelectorAll('#cropTable tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(filter) ? '' : 'none';
    });
});
</script>

<?php include '../includes/footer.php'; ?>