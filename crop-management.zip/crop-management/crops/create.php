<?php
// crops/create.php
require_once '../db.php';
require_once '../auth.php';
requireLogin();

if ($_POST) {
    if (verify_csrf($_POST['csrf_token'] ?? '')) {
        
        // Get growth_days from crop_types
        $stmt = $pdo->prepare("SELECT growth_days FROM crop_types WHERE id = ?");
        $stmt->execute([$_POST['crop_type_id']]);
        $growth = $stmt->fetchColumn();

        $stmt = $pdo->prepare("
            INSERT INTO crops 
            (user_id, crop_type_id, growth_days, field_name, planting_date, current_stage, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $_SESSION['user_id'],
            $_POST['crop_type_id'],
            $growth,
            trim($_POST['field_name']),
            $_POST['planting_date'],
            $_POST['current_stage'],
            trim($_POST['notes'] ?? '')
        ]);

        header("Location: ../crops/index.php?success=1");
        exit();
    }
}

?>

<?php include '../includes/header.php'; ?>
<?php include '../includes/navbar.php'; ?>

<div class="max-w-2xl mx-auto bg-white rounded-3xl shadow p-8 mt-10">
    <h1 class="text-3xl font-bold mb-8">Add New Crop</h1>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

        <div class="grid grid-cols-2 gap-6">
            <div>
                <label class="block mb-2 font-medium">Crop Type</label>
                <select name="crop_type_id" required class="w-full px-4 py-3 border rounded-2xl">
                    <?php
                    $types = $pdo->query("SELECT * FROM crop_types ORDER BY name");
                    while($t = $types->fetch()): ?>
                        <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['name']) ?> (<?= $t['growth_days'] ?> days)</option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div>
                <label class="block mb-2 font-medium">Field Name</label>
                <input type="text" name="field_name" required 
                       class="w-full px-4 py-3 border rounded-2xl">
            </div>
        </div>

        <div class="mt-6">
            <label class="block mb-2 font-medium">Planting Date</label>
            <input type="date" name="planting_date" value="<?= date('Y-m-d') ?>" required 
                   class="w-full px-4 py-3 border rounded-2xl">
        </div>

        <div class="mt-6">
            <label class="block mb-2 font-medium">Initial Stage</label>
            <select name="current_stage" class="w-full px-4 py-3 border rounded-2xl">
                <option value="Seed">Seed</option>
                <option value="Germination">Germination</option>
                <option value="Vegetative" selected>Vegetative</option>
                <option value="Flowering">Flowering</option>
            </select>
        </div>

        <div class="mt-6">
            <label class="block mb-2 font-medium">Notes</label>
            <textarea name="notes" rows="4" class="w-full px-4 py-3 border rounded-3xl"></textarea>
        </div>

        <button type="submit" 
                class="mt-10 w-full bg-green-600 hover:bg-green-700 text-white py-4 rounded-2xl font-semibold">
            Save Crop
        </button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>