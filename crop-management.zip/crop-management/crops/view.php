<?php
// crops/view.php - FULL LOGS DISPLAY
require_once '../db.php';
require_once '../auth.php';
requireLogin();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $pdo->prepare("
    SELECT c.*, ct.name as crop_name, ct.growth_days 
    FROM crops c 
    JOIN crop_types ct ON c.crop_type_id = ct.id 
    WHERE c.id = ? AND c.user_id = ?
");
$stmt->execute([$id, $_SESSION['user_id']]);
$crop = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$crop) {
    die("Crop not found or access denied.");
}
?>

<?php include '../includes/header.php'; ?>
<?php include '../includes/navbar.php'; ?>

<div class="max-w-6xl mx-auto px-6 py-8">
    <!-- Crop Header -->
    <div class="bg-white rounded-3xl shadow-xl p-8 mb-8">
        <div class="flex justify-between">
            <div>
                <h1 class="text-4xl font-bold"><?= htmlspecialchars($crop['crop_name']) ?></h1>
                <p class="text-2xl text-gray-600"><?= htmlspecialchars($crop['field_name']) ?></p>
            </div>
            <span class="px-6 py-3 text-lg font-semibold bg-green-100 text-green-700 rounded-2xl">
                <?= $crop['current_stage'] ?>
            </span>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-6 mt-8">
            <div class="text-center bg-gray-50 p-4 rounded-2xl">
                <p class="text-sm text-gray-500">Planted</p>
                <p class="font-bold"><?= $crop['planting_date'] ?></p>
            </div>
            <div class="text-center bg-gray-50 p-4 rounded-2xl">
                <p class="text-sm text-gray-500">Expected Harvest</p>
                <p class="font-bold text-amber-600"><?= $crop['expected_harvest_date'] ?></p>
            </div>
            <div class="text-center bg-gray-50 p-4 rounded-2xl">
                <p class="text-sm text-gray-500">Days Planted</p>
                <p class="font-bold"><?= floor((strtotime('today') - strtotime($crop['planting_date'])) / 86400) ?></p>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        <a href="../logs/water.php?crop_id=<?= $id ?>" class="bg-blue-50 hover:bg-blue-100 p-6 rounded-3xl text-center">💧 Watering</a>
        <a href="../logs/fertilizer.php?crop_id=<?= $id ?>" class="bg-amber-50 hover:bg-amber-100 p-6 rounded-3xl text-center">🌿 Fertilizer</a>
        <a href="../logs/disease.php?crop_id=<?= $id ?>" class="bg-red-50 hover:bg-red-100 p-6 rounded-3xl text-center">🦠 Disease</a>
        <a href="../logs/yield.php?crop_id=<?= $id ?>" class="bg-emerald-50 hover:bg-emerald-100 p-6 rounded-3xl text-center">📊 Yield</a>
    </div>

    <!-- All Logs Sections -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">

        <!-- Watering Logs -->
        <div>
            <h3 class="font-semibold text-lg mb-4">💧 Recent Watering Logs</h3>
            <div class="bg-white rounded-3xl shadow p-6">
                <?php
                $water = $pdo->prepare("SELECT * FROM watering_logs WHERE crop_id = ? ORDER BY watering_date DESC LIMIT 5");
                $water->execute([$id]);
                if ($water->rowCount() == 0) echo "<p class='text-gray-500 py-8 text-center'>No watering records yet.</p>";
                while($row = $water->fetch()): ?>
                    <div class="py-4 border-b last:border-0 flex justify-between">
                        <div>
                            <strong><?= $row['watering_date'] ?></strong> 
                            <span class="text-blue-600 ml-4"><?= $row['amount_ml'] ?> ml</span>
                        </div>
                        <div class="text-sm text-gray-600"><?= htmlspecialchars($row['notes']) ?></div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>

        <!-- Fertilizer Logs -->
        <div>
            <h3 class="font-semibold text-lg mb-4">🌿 Recent Fertilizer Applications</h3>
            <div class="bg-white rounded-3xl shadow p-6">
                <?php
                $fert = $pdo->prepare("SELECT * FROM fertilizer_logs WHERE crop_id = ? ORDER BY application_date DESC LIMIT 5");
                $fert->execute([$id]);
                if ($fert->rowCount() == 0) echo "<p class='text-gray-500 py-8 text-center'>No fertilizer records yet.</p>";
                while($row = $fert->fetch()): ?>
                    <div class="py-4 border-b last:border-0 flex justify-between">
                        <div>
                            <strong><?= $row['application_date'] ?></strong> 
                            <span class="ml-4"><?= htmlspecialchars($row['fertilizer_name']) ?></span>
                        </div>
                        <div><?= $row['quantity'] ?> <?= $row['unit'] ?></div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>

        <!-- Disease Logs -->
        <div>
            <h3 class="font-semibold text-lg mb-4">🦠 Disease / Pest Records</h3>
            <div class="bg-white rounded-3xl shadow p-6">
                <?php
                $disease = $pdo->prepare("SELECT * FROM crop_diseases WHERE crop_id = ? ORDER BY detection_date DESC LIMIT 5");
                $disease->execute([$id]);
                if ($disease->rowCount() == 0) echo "<p class='text-gray-500 py-8 text-center'>No disease records yet.</p>";
                while($row = $disease->fetch()): ?>
                    <div class="py-4 border-b last:border-0">
                        <strong><?= $row['detection_date'] ?> - <?= htmlspecialchars($row['disease_name']) ?></strong>
                        <?php if($row['treatment']): ?>
                            <p class="text-sm text-green-600 mt-1">Treatment: <?= htmlspecialchars($row['treatment']) ?></p>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>

        <!-- Yield Records -->
        <div>
            <h3 class="font-semibold text-lg mb-4">📊 Yield Records</h3>
            <div class="bg-white rounded-3xl shadow p-6">
                <?php
                $yield = $pdo->prepare("SELECT * FROM yields WHERE crop_id = ? ORDER BY harvest_date DESC LIMIT 5");
                $yield->execute([$id]);
                if ($yield->rowCount() == 0) echo "<p class='text-gray-500 py-8 text-center'>No yield records yet.</p>";
                while($row = $yield->fetch()): ?>
                    <div class="py-4 border-b last:border-0 flex justify-between">
                        <div>
                            <strong><?= $row['harvest_date'] ?></strong>
                        </div>
                        <div class="font-semibold"><?= $row['amount'] ?> <?= $row['unit'] ?></div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>

    </div>
</div>

<?php include '../includes/footer.php'; ?>