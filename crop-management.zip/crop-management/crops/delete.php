<?php
// crops/delete.php
require_once '../db.php';
require_once '../auth.php';
requireLogin();

if (isset($_GET['id']) && verify_csrf($_GET['csrf'] ?? '')) {
    $stmt = $pdo->prepare("DELETE FROM crops WHERE id = ? AND user_id = ?");
    $stmt->execute([$_GET['id'], $_SESSION['user_id']]);
}

header("Location: index.php");
exit();
?>