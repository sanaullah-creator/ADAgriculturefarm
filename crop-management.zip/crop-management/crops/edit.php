<?php
// crops/edit.php
require_once '../db.php';
require_once '../auth.php';
requireLogin();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (verify_csrf($_POST['csrf_token'] ?? '')) {
        $stmt = $pdo->prepare("
            UPDATE crops 
            SET field_name = ?, area_acres = ?, planting_date = ?, 
                current_stage = ?, notes = ?
            WHERE id = ? AND user_id = ?
        ");
        $stmt->execute([
            trim($_POST['field_name']),
            (float)$_POST['area_acres'],
            $_POST['planting_date'],
            $_POST['current_stage'],
            trim($_POST['notes'] ?? ''),
            $id,
            $_SESSION['user_id']
        ]);
        header("Location: view.php?id=$id&success=updated");
        exit();
    }
}

// Fetch crop
$stmt = $pdo->prepare("SELECT * FROM crops WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $_SESSION['user_id']]);
$crop = $stmt->fetch();

if (!$crop) die("Crop not found.");
?>

<?php include '../includes/header.php'; ?>
<?php include '../includes/navbar.php'; ?>

<div class="max-w-2xl mx-auto bg-white rounded-3xl shadow-xl p-8 mt-10">
    <h1 class="text-3xl font-bold mb-8">Edit Crop</h1>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

        <div>
            <label class="block font-medium mb-2">Field Name</label>
            <input type="text" name="field_name" value="<?= htmlspecialchars($crop['field_name']) ?>" required 
                   class="w-full px-4 py-3 border rounded-2xl">
        </div>

        <div class="mt-6">
            <label class="block font-medium mb-2">Area (Acres)</label>
            <input type="number" step="0.01" name="area_acres" value="<?= $crop['area_acres'] ?>" required 
                   class="w-full px-4 py-3 border rounded-2xl">
        </div>

        <div class="grid grid-cols-2 gap-6 mt-6">
            <div>
                <label class="block font-medium mb-2">Planting Date</label>
                <input type="date" name="planting_date" value="<?= $crop['planting_date'] ?>" required 
                       class="w-full px-4 py-3 border rounded-2xl">
            </div>
            <div>
                <label class="block font-medium mb-2">Current Stage</label>
                <select name="current_stage" class="w-full px-4 py-3 border rounded-2xl">
                    <option value="Seed" <?= $crop['current_stage']=='Seed'?'selected':'' ?>>Seed</option>
                    <option value="Germination" <?= $crop['current_stage']=='Germination'?'selected':'' ?>>Germination</option>
                    <option value="Vegetative" <?= $crop['current_stage']=='Vegetative'?'selected':'' ?>>Vegetative</option>
                    <option value="Flowering" <?= $crop['current_stage']=='Flowering'?'selected':'' ?>>Flowering</option>
                    <option value="Harvest" <?= $crop['current_stage']=='Harvest'?'selected':'' ?>>Harvest</option>
                </select>
            </div>
        </div>

        <div class="mt-6">
            <label class="block font-medium mb-2">Notes</label>
            <textarea name="notes" rows="5" class="w-full px-4 py-3 border rounded-3xl"><?= htmlspecialchars($crop['notes'] ?? '') ?></textarea>
        </div>

        <button type="submit" class="mt-10 w-full bg-green-600 hover:bg-green-700 text-white py-4 rounded-2xl font-semibold">
            Save Changes
        </button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>