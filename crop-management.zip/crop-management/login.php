<?php
require_once 'db.php';
require_once 'auth.php';

if (isLoggedIn()) {
    header("Location: index.php");
    exit();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Debug output
    echo "<pre>Debug Info:\n";
    echo "Username entered: " . htmlspecialchars($username) . "\n";
    
    $stmt = $pdo->prepare("SELECT password FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $stored_hash = $stmt->fetchColumn();
    
    echo "Stored hash exists: " . ($stored_hash ? 'YES' : 'NO') . "\n";
    if ($stored_hash) {
        echo "Hash length: " . strlen($stored_hash) . "\n";
        $verify = password_verify($password, $stored_hash);
        echo "password_verify result: " . ($verify ? 'SUCCESS' : 'FAILED') . "\n";
    }
    echo "</pre>";
    
    if (verify_csrf($_POST['csrf_token'] ?? '')) {
        if (loginUser($username, $password)) {
            header("Location: index.php");
            exit();
        } else {
            $error = "Invalid username or password!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - CropGuard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center">
    <div class="bg-white p-8 rounded-3xl shadow-xl w-full max-w-md">
        <h1 class="text-4xl font-bold text-center mb-8">CropGuard</h1>

        <?php if($error): ?>
            <div class="bg-red-100 text-red-700 p-4 rounded-2xl mb-6 text-center">
                <?= $error ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            
            <div class="mb-6">
                <label class="block mb-2">Username</label>
                <input type="text" name="username" value="" placeholder="Enter UserName" required 
                       class="w-full px-4 py-3 border rounded-2xl">
            </div>
            
            <div class="mb-6">
                <label class="block mb-2">Password</label>
                <input type="password" name="password" value="" placeholder="Enter Password" required 
                       class="w-full px-4 py-3 border rounded-2xl">
            </div>
            <button type="submit" class="w-full bg-green-600 text-white py-4 rounded-2xl text-lg font-semibold">
                Login
            </button>
        </form>
    </div>
</body>
</html>