<?php
// index.php - ENHANCED DASHBOARD
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
requireLogin();
?>

<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<div class="max-w-7xl mx-auto px-6 py-8">
    <div class="flex justify-between items-center mb-8">
        <div>
            <h1 class="text-4xl font-bold text-gray-800">Dashboard</h1>
            <p class="text-gray-600">Overview of your farm - <?= date('F Y') ?></p>
        </div>
        <a href="crops/create.php" 
           class="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-2xl flex items-center gap-2 font-semibold">
            <i class="fas fa-plus"></i> Add New Crop
        </a>
    </div>

    <!-- Main Stats -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        <?php
        $user_id = $_SESSION['user_id'];

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM crops WHERE user_id = ? AND status = 'Active'");
        $stmt->execute([$user_id]);
        $active_crops = $stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM crops WHERE user_id = ? AND status = 'Harvested'");
        $stmt->execute([$user_id]);
        $harvested = $stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) as total FROM yields y 
                               JOIN crops c ON y.crop_id = c.id WHERE c.user_id = ?");
        $stmt->execute([$user_id]);
        $total_yield = $stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM crops WHERE user_id = ? 
                               AND expected_harvest_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 14 DAY)");
        $stmt->execute([$user_id]);
        $nearing = $stmt->fetchColumn();
        ?>
        <div class="bg-white rounded-3xl p-6 shadow">
            <p class="text-gray-500">Active Crops</p>
            <p class="text-5xl font-bold text-green-600"><?= $active_crops ?></p>
        </div>
        <div class="bg-white rounded-3xl p-6 shadow">
            <p class="text-gray-500">Harvested</p>
            <p class="text-5xl font-bold text-emerald-600"><?= $harvested ?></p>
        </div>
        <div class="bg-white rounded-3xl p-6 shadow">
            <p class="text-gray-500">Total Yield</p>
            <p class="text-5xl font-bold text-amber-600"><?= number_format($total_yield, 1) ?> kg</p>
        </div>
        <div class="bg-white rounded-3xl p-6 shadow">
            <p class="text-gray-500">Nearing Harvest</p>
            <p class="text-5xl font-bold text-orange-600"><?= $nearing ?></p>
        </div>
    </div>

    <!-- Average Production -->
    <div class="bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-3xl p-8 mb-10">
        <h2 class="text-xl font-medium">Average Production</h2>
        <?php
        $avg = $pdo->prepare("
            SELECT COALESCE(AVG(y.amount / NULLIF(c.area_acres, 0)), 0) as avg_per_acre 
            FROM yields y 
            JOIN crops c ON y.crop_id = c.id 
            WHERE c.user_id = ? AND c.area_acres > 0
        ");
        $avg->execute([$user_id]);
        $avg_per_acre = round($avg->fetchColumn(), 2);
        ?>
        <p class="text-6xl font-bold mt-2"><?= $avg_per_acre ?> <span class="text-2xl font-normal">kg/acre</span></p>
        <p class="text-purple-200 mt-1">Average yield per acre across all harvests</p>
    </div>

    <!-- Overdue Watering Alerts -->
    <?php
    $overdue = $pdo->prepare("
        SELECT c.id, c.field_name, ct.name as crop_name, 
               DATEDIFF(CURDATE(), MAX(w.watering_date)) as days
        FROM crops c
        LEFT JOIN watering_logs w ON c.id = w.crop_id
        JOIN crop_types ct ON c.crop_type_id = ct.id
        WHERE c.user_id = ? AND c.status = 'Active'
        GROUP BY c.id
        HAVING days > 7 OR days IS NULL
        ORDER BY days DESC LIMIT 5
    ");
    $overdue->execute([$user_id]);
    $alerts = $overdue->fetchAll();
    ?>
    <?php if(count($alerts) > 0): ?>
    <div class="bg-red-50 border border-red-200 rounded-3xl p-6 mb-10">
        <h3 class="text-red-700 font-semibold flex items-center gap-2 mb-4">
            <i class="fas fa-exclamation-triangle"></i> Watering Overdue
        </h3>
        <?php foreach($alerts as $alert): ?>
        <div class="bg-white p-4 rounded-2xl mb-3 flex justify-between items-center">
            <div>
                <strong><?= htmlspecialchars($alert['crop_name']) ?></strong> - <?= htmlspecialchars($alert['field_name']) ?>
            </div>
            <div class="text-red-600 font-medium"><?= $alert['days'] ?> days overdue</div>
            <a href="crops/view.php?id=<?= $alert['id'] ?>" class="text-blue-600">Take Action →</a>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- All Crops -->
    <h2 class="text-2xl font-semibold mb-6">Your Crops</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php
        $crops = $pdo->prepare("
            SELECT c.*, ct.name as crop_name,
                   DATEDIFF(c.expected_harvest_date, CURDATE()) as days_left,
                   (SELECT COALESCE(SUM(amount),0) FROM yields WHERE crop_id = c.id) as total_yield
            FROM crops c
            JOIN crop_types ct ON c.crop_type_id = ct.id
            WHERE c.user_id = ?
            ORDER BY c.expected_harvest_date ASC
        ");
        $crops->execute([$user_id]);
        $all_crops = $crops->fetchAll();

        foreach($all_crops as $crop):
            $per_acre = $crop['area_acres'] > 0 ? round($crop['total_yield'] / $crop['area_acres'], 1) : 0;
        ?>
        <div class="bg-white rounded-3xl shadow hover:shadow-xl transition p-6">
            <div class="flex justify-between">
                <h3 class="font-bold text-lg"><?= htmlspecialchars($crop['crop_name']) ?></h3>
                <span class="text-xs px-3 py-1 rounded-full <?= $crop['status']=='Active' ? 'bg-green-100 text-green-700' : 'bg-gray-100' ?>">
                    <?= $crop['status'] ?>
                </span>
            </div>
            <p class="text-gray-500"><?= htmlspecialchars($crop['field_name']) ?> • <?= $crop['area_acres'] ?> acres</p>

            <div class="mt-6 space-y-3 text-sm">
                <div class="flex justify-between">
                    <span class="text-gray-600">Stage:</span>
                    <span class="font-medium"><?= $crop['current_stage'] ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-600">Harvest In:</span>
                    <span class="font-medium <?= $crop['days_left'] <= 14 ? 'text-amber-600' : '' ?>">
                        <?= max(0, $crop['days_left']) ?> days
                    </span>
                </div>
                <?php if($crop['total_yield'] > 0): ?>
                <div class="flex justify-between">
                    <span class="text-gray-600">Per Acre:</span>
                    <span class="font-medium"><?= $per_acre ?> kg/acre</span>
                </div>
                <?php endif; ?>
            </div>

            <a href="crops/view.php?id=<?= $crop['id'] ?>" 
               class="mt-6 block text-center py-3 bg-gray-100 hover:bg-gray-200 rounded-2xl font-medium">
                View Full Details →
            </a>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>